package com.upgrad.movieapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieappApplicationTests {

	@Test
	void contextLoads() {
	}

}
